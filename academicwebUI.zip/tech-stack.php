<div class="tech-list">
    <ul class="list-unstyled d-flex flex-wrap justify-content-center align-items-center"> 
        <li>
            <img src="./assets/media/technologies/1.webp" alt="">
        </li>   
        <li>
            <img src="./assets/media/technologies/2.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/3.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/4.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/5.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/6.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/7.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/8.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/9.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/10.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/11.webp" alt="">
        </li>  
        <li>
            <img src="./assets/media/technologies/12.webp" alt="">
        </li>
        <li>
            <img src="./assets/media/technologies/13.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/14.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/15.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/16.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/17.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/18.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/19.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/20.webp" alt="">
        </li>
        <li>
            <img src="./assets/media/technologies/21.webp" alt="">
        </li>   
        <li>
            <img src="./assets/media/technologies/22.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/23.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/24.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/25.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/26.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/27.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/28.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/29.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/30.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/31.webp" alt="">
        </li>   
        <li>
            <img src="./assets/media/technologies/32.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/33.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/34.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/35.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/36.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/37.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/38.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/39.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/40.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/41.webp" alt="">
        </li>   
        <li>
            <img src="./assets/media/technologies/42.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/43.webp" alt="">
        </li> 
        <li>
            <img src="./assets/media/technologies/44.webp" alt="">
        </li> 
    </ul>
</div>
<div class="m-0 p-5 our-impact-categories d-flex flex-wrap justify-content-lg-around justify-content-center align-items-center text-center">
    <div class="impact-cat m-2">
        <h2>3+</h2>
        <p>Years</p>
    </div>
    <div class="impact-cat m-2">
        <h2>13</h2>
        <p>Industries</p>
    </div>
    <div class="impact-cat m-2">
        <h2>25+</h2>
        <p>Employees</p>
    </div>
    <div class="impact-cat m-2">
        <h2>16</h2>
        <p>Brands</p>
    </div>
</div>