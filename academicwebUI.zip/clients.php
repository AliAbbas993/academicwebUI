
<div class="clients-list">
    <ul class="list-unstyled d-flex flex-wrap justify-content-center align-items-center mt-5">
        <li>
            <img src="./assets/media/clients/1.webp" alt="" />
        </li>
        <li>
            <img src="./assets/media/clients/2.webp" alt="" />
        </li>
        <li>
            <img src="./assets/media/clients/3.webp" alt=""/>
        </li>
        <li>
            <img src="./assets/media/clients/4.webp" alt="" />
        </li>
        <li>
            <img src="./assets/media/clients/5.webp" alt=""/>
        </li>
        <li>
            <img src="./assets/media/clients/6.webp" alt="" />
        </li>
    </ul>
</div>

       